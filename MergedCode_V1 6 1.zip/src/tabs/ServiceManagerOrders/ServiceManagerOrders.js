import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser } from '@fortawesome/free-solid-svg-icons';
import ServiceOrderList from "./ServiceOrderList";

const ServiceManagerOrders = () => {

    const [isDropdownOpen, setIsDropdownOpen] = useState(false);
    const navigate = useNavigate(); 
   
    const toggleDropdown = () => {
        setIsDropdownOpen(!isDropdownOpen);
    };

    const handleLogout = () => {
        // Perform logout actions if needed
        // For example, clearing session, etc.
        // Then redirect to the login page
        navigate('/'); // Redirect to the login page
    };

    const handleMyProfile = () => {
        // Redirect to the profile page
        navigate('/profile');
    }
  return (
    <div className="customer-home-container">
      <aside className="sidebar">
        <nav>
          <ul>
            <li>
              <a to="/admin-home">Dashboard</a>
            </li>
            <li>
              <a href="/serviceManager-orders">Service Orders</a>
            </li>
            <li>
              <a >Settings</a>
            </li>
            <li>
              <a >Help</a>
            </li>
            <li>
              <a>About</a>
            </li>
          </ul>
        </nav>
      </aside>
      <main className="main-content">
      <header>
        <div className="profile-icon profile-icon-container" onClick={toggleDropdown}>
            <FontAwesomeIcon icon={faUser} />
            {isDropdownOpen && (
                    <div className="dropdown">
                        <ul>
                            <li><a href="#" onClick={handleMyProfile}>My Profile</a></li>
                            <li><a href="#" onClick={handleLogout}>Logout</a></li>
                        </ul>
                    </div>
                )}
             </div>
        </header>
        
        <section className="content">
        <div className="orders-page-container">
            <h2>Orders</h2>
             
            <ServiceOrderList/>
        </div>
        </section>
        </main>
           </div>
    
  );
};

export default ServiceManagerOrders;
