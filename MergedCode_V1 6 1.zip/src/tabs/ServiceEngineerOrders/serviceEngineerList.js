import React, { useEffect, useState } from "react";
//import InventoryOrders from "./InventoryOrders";
import axios from "axios";
import { blueGrey } from "@mui/material/colors";
import OrdersList from "../OrdersList/OrdersList";
import "../OrdersList/OrdersList.css";
import UserInfo from "../../components/UserInfo";
 
const ServiceEngineerList = () => {
    const [noApproval, setNoApproval] = useState(true);
    const [Order, setOrder] = useState([]);
    const [orderItem, setorderItem] = useState([]);
    const [date, setDate] = useState("")
    const [comments, setComments] = useState("");
    const [TaskID, setTaskID] = useState(0);
    useEffect(() => {
        fetchOrderData();
    }, []);
    
  const userEmail = localStorage.getItem("email");
  let userGroups = localStorage.getItem("groups");
  console.log("----usergroup---"+userGroups);
   
    //Data from API for date and orderID
   
    const fetchOrderData = async () => {
        userGroups = userGroups.replace(/['"]+/g, '')
        const baseURL1 = `http://localhost:8899/api/tasklist/GetAllOpenOrders/${userGroups}`;
        try {
            const orderData = await axios.get(baseURL1).then((res) => res.data);
 
            setOrder([...orderData]);
        } catch (err) {
            console.log(err.message);
        }
    };
 
    const moveToApproval = async (id) => {
        setTaskID(id);
        setNoApproval(false);
        const baseURL = `http://localhost:8899/api/tasklist/${id}/gettaskinfo`;
        try {
            let planDetails = await axios.get(baseURL).then((res) => res.data);
            let dataItem = planDetails.orderitem;
            let newItem = dataItem.map(function (item) {
                return { ...item, taskId: id };
            });
 
            setorderItem([...newItem]);
        } catch (err) {
            console.log(err);
        }
    };
 
    //   const variables = {
    //     variables: [
    //       { name: "isApprove", value: '"true"' },
    //       { name: "ApproverComments", value: '"approved"' },
    //       { name: "hasBroadbandService", value: '"true"' },
    //     ],
    //   };

    const DateChange=(val)=>{
        
        let DateSplit =val.split("-")
        let year =Number(DateSplit[0])
        console.log(year)
        let month =Number(DateSplit[1]);
        console.log(month);
        let day =Number(DateSplit[2])
         
        let scheduleDate=new Date(year,month,day,0,0);
        console.log(scheduleDate.toISOString())
        setDate(scheduleDate.toISOString().substring(0,scheduleDate.toISOString().length-1));
        
            }

    const Submit = async () => {
       
        const variables = {
            "variables": [{ "name": "scheduleddate", "value": "\""+`${date}`+ "\"" }, { "name": "IsNotificationsent", "value": "\"true\"" }
            ]
          
        }
        
        // setNoApproval(true);
        try {
            const result = await axios
                .patch(
                    `http://localhost:8899/api/tasklist/CompleteTask/${TaskID}`,
                    variables
                )
                .then((res) => {
                    console.log(res.data);
                });
        } catch (err) {
            console.log(err.message);
        }
       
    };
 
 
    return (
       
        <div className="orders-list">
            {Order.length === 0 ? (
                <div className="no-orders-message">No orders to show on the page.</div>
            ) : noApproval ? (
                Order.map((order) => (
                    <div key={order.id} className="order-card">
                        <div className="order-header">
                            <div>
                                <strong>Order ID:</strong> {order.id}
                            </div>
                            <div>
                                <strong>Date:</strong> {order.creationDate.substring(0,10)}
                            </div>
                            {/* <div>
                                <strong>Status:</strong> {order.status}
                            </div> */}
                            <button
                                style={{ width: "80px" }}
                                onClick={() => moveToApproval(order.id)}
                            >
                                Details
                            </button>
                        </div>
                    </div>
                ))
            ) : (
                <div>
                     { orderItem.length>0 &&<UserInfo userDetails={[...orderItem]}/>}
                    <div className="order-details">
                        <h3>List of Plans</h3>
                        <div>
                            {orderItem.map((plan, index) => (<div style={{display:"flex"}}>
                                <div key={index} className="listItems">
                                    <div><strong>Plan ID :</strong> <span>{plan.id}</span></div><div> <strong>Amount:</strong>
                                        <span> {plan.order.priceAmount}</span></div>
                                    <div><strong>Quantity :</strong><span>{plan.quantity}</span></div>
                                    <div><strong>Data :</strong> <span>UNLIMITED</span></div>
                                    <div><strong>Validity :</strong>
                                        <span>BillCycle</span></div>
 
                                </div>
                          </div>  ))}
                            <label for="comments" style={{ paddingTop: "10px" }}>Comments:</label>
                            <textarea id="comments"
                                name="comments"
                                value={comments}
                                rows="3"
                                cols="36"
                                onChange={(e) => setComments(e.target.value)}
                                style={{ border: "rgb(207 204 204) solid 2px", borderRadius: "5px" }}></textarea>
                            <div style={{ marginTop: "10px" }}>
 
                                <label> Installation Date:</label><input type="date" name="InstallDate" onChange={(e) => DateChange(e.target.value)} style={{ width: "260px" }} />
 
                                 
                            </div>
 
                        </div>
 
                    </div>
                    <a href="/serviceEngineer-orders">  <button style={{ width: "80px" }} onClick={() => Submit()}>
                        Submit
                    </button></a>
                </div>
            )}
        </div>
 
    )
 
}
export default ServiceEngineerList;