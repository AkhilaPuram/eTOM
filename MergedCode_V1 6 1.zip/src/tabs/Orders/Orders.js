// Bills.js
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Orders.css"; // Import CSS for Bills component
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faUser,
  faAngleDown,
  faAngleUp,
} from "@fortawesome/free-solid-svg-icons";
// import { OrderListFetch } from "../../components/HomePage/OrderListFetch.json";

function Orders({ email }) {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const navigate = useNavigate();

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const response = await fetch(
          `http://10.13.8.223:8899/api/etom/myorders/${email}`
        );
        const data = await response.json();
        console.log(data);
        setOrders(data);
      } catch (error) {
        console.error("Error fetching orders:", error);
      }
    };

    fetchOrders();
  }, [email]);

  const handleLogout = () => {
    navigate("/"); // Redirect to the login page
  };

  const handleMyProfile = () => {
    // Redirect to the profile page
    navigate("/profile");
  };

  const toggleOrderDetails = (index) => {
    const updatedOrders = [...orders];
    updatedOrders[index].expanded = !updatedOrders[index].expanded;
    setOrders(updatedOrders);
  };

  // Mock data for orders
  const [orders, setOrders] = useState([
    {
      customer: null,
      order: {
        id: "",
        customer: {
          id: "",
          emailID: "",
          suffix: "",
          homePhone: "",
          customrType: "",
          fax: "",
          middleName: "",
          businessPhone: "",
          firstName: "",
          lastName: "",
          title: "",
        },
        splittingPreference: "",
        specialInstructions: "",
        shippingAmount: "",
        shippingMethod: "",
        orderDate: "",
        priceAmount: "",
        shippingAddress: "",
        ordersSubtotal: "",
        status: "",
      },
      orderitem: [
        {
          id: "",
          content: "",
          order: "",
          shippingCurrency: "",
          unitPriceCurrency: "",
          description: "",
          orderLineID: "",
          quantity: "",
          productID: "",
          taxCurrency: "",
          taxAmount: "",
          msrpamount: "",
          shippingAmount: "",
          unitPriceAmount: "",
          msrpcurrency: "",
        },
      ],
    },
  ]);

  // Function to handle expanding/collapsing order details
  // const toggleOrderDetails = (index) => {
  //   const updatedOrders = [...orders];
  //   updatedOrders[index].expanded = !updatedOrders[index].expanded;
  //   setOrders(updatedOrders);
  // };
  const toggleOrderItemDetails = (orderIndex, itemIndex) => {
    const updatedOrders = [...orders];
    updatedOrders[orderIndex].orderitem[itemIndex].expanded =
      !updatedOrders[orderIndex].orderitem[itemIndex].expanded;
    setOrders(updatedOrders);
  };
  return (
    <div className="customer-home-container">
      <aside className="sidebar">
        <nav>
          <ul>
            <li>
              <a href="/customer-home">Home</a>
            </li>
            <li>
              <a href="/orders">Orders</a>
            </li>
            {/* <li>
              <a href="/bills">Bills</a>
            </li> */}
          </ul>
        </nav>
      </aside>
      <main className="main-content">
        <header>
          <div
            className="profile-icon profile-icon-container"
            onClick={toggleDropdown}
          >
            <FontAwesomeIcon icon={faUser} />
            {isDropdownOpen && (
              <div className="dropdown">
                <ul>
                  <li>
                    <a href="#" onClick={handleMyProfile}>
                      My Profile
                    </a>
                  </li>
                  <li>
                    <a href="#" onClick={handleLogout}>
                      Logout
                    </a>
                  </li>
                </ul>
              </div>
            )}
          </div>
        </header>
        <section className="content">
          <div className="orders-container">
            <h2 style={{ fontFamily: "serif" }}>All Orders</h2>
            {orders.map((orderData, orderIndex) => (
              <div key={orderIndex}>
                {/* <h3>Order {orderData.order.id}</h3> */}
                {orderData.orderitem.map((item, itemIndex) => (
                  <div key={itemIndex}>
                    <div
                      className={`order-item li-order ${
                        item.expanded ? "expanded" : ""
                      }`}
                    >
                      <div className="li-content">
                        <span className="order-content">
                          Order Id: {item.id}
                        </span>
                        <span className="order-content">
                          Quantity: {item.quantity}
                        </span>
                        <span className="order-content">
                          Amount: {item.taxAmount}
                        </span>
                        {!item.expanded && (
                          <div
                            className="expand-button"
                            onClick={() =>
                              toggleOrderItemDetails(orderIndex, itemIndex)
                            }
                          >
                            <FontAwesomeIcon icon={faAngleDown} />
                          </div>
                        )}
                        {item.expanded && (
                          <div
                            className="collapse-button"
                            onClick={() =>
                              toggleOrderItemDetails(orderIndex, itemIndex)
                            }
                          >
                            <FontAwesomeIcon icon={faAngleUp} />
                          </div>
                        )}
                      </div>

                      {item.expanded && (
                        <div className="order-details li-order-expand">
                          <span className="order-content-expand">
                            Description: {item.description}
                          </span>
                          <span className="order-content-expand">
                            ShippingAmount: {item.shippingAmount}
                          </span>
                          <span className="order-content-expand">
                            Price Amount: {item.unitPriceAmount}
                          </span>
                          {/* <span className="order-content-expand">
                            Product ID: {item.productID}
                          </span> */}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}

export default Orders;
