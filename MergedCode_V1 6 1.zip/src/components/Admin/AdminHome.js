// src/CustomerHome.js
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUser, faChevronRight } from "@fortawesome/free-solid-svg-icons";
import Profile from "../../tabs/Profile/Profile";
import "./AdminHome.css";
import Keycloak from "keycloak-js";

function AdminHome({handleLogout}) {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const navigate = useNavigate();

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };
  const [email, setEmail] = useState("");
  const [groups, setGroups] = useState([]);

  useEffect(() => {
    const userEmail = localStorage.getItem("email");
    const userGroups = localStorage.getItem("groups");

    if (userEmail && userGroups) {
      setEmail(userEmail);
      setGroups(userGroups);
    }
  }, []);
  const handlePayment = () => {
    // Open payment page in a new tab
    window.open("/payment", "_blank");
  };

  //const handlelogout = () => {
   
  //     alert('hi');
  //     let initOptions = {
  //       url: "http://10.13.1.180:18080/auth/",
  //       realm: "camunda-platform",
  //       clientId: "react-client",
  //     };
  
  //     let keycloak = new Keycloak(initOptions);
  //     keycloak
  //       .init({
  //         onLoad: "check-sso",
  //         checkLoginIframe: true,
  //         pkceMethod: "S256",
  //       })
  //       .then(()=>{
  //         console.log("inside auth");
  //         //if ( keycloak) {
  //           keycloak.logout({ redirectUri: "http://localhost:4000/" });
  //         //}
  //       })
          
  //       alert('keycloak' + keycloak);
  //   // Perform logout actions if needed
  //   // For example, clearing session, etc.
  //   // Then redirect to the login page
  //  navigate("/"); // Redirect to the login page
  //handleLogout();
   //};

  const handleMyProfile = () => {
    // Redirect to the profile page
    navigate("/profile");
  };

  const [searchInput, setSearchInput] = useState("");
  const [customerDetails, setCustomerDetails] = useState(null);
  const [searchPerformed, setSearchPerformed] = useState(false);

  const staticCustomerData = [
    {
      id: 1,
      name: "John",
      accountNumber: "AC123456",
      phoneNumber: "1234567890",
    },
    {
      id: 2,
      name: "Jane",
      accountNumber: "AC987654",
      phoneNumber: "9876543210",
    },
    // Add more static customer data as needed
  ];

  // Function to handle search input change
  const handleSearchInputChange = (event) => {
    setSearchInput(event.target.value);
  };

  // Function to handle search
  const handleSearch = () => {
    if (searchInput.trim() === "") {
      // If search input is empty, reset customer details and searchPerformed
      setCustomerDetails(null);
      setSearchPerformed(false);
      return;
    }
    // Perform search logic here using static customer data
    const foundCustomer = staticCustomerData.find(
      (customer) =>
        customer.accountNumber.includes(searchInput) ||
        customer.phoneNumber.includes(searchInput) ||
        customer.name.toLowerCase().includes(searchInput.toLowerCase())
    );
    setCustomerDetails(foundCustomer);
    setSearchPerformed(true);
  };
  return (
    <div className="customer-home-container">
      <aside className="sidebar">
        <nav>
          <ul>
            <li>
              <a href="/admin-home">Dashboard</a>
            </li>
            <li>
              <a href="/admin-orders">Manage Orders</a>
            </li>
          </ul>
        </nav>
      </aside>
      <main className="main-content">
        <header>
          <div
            className="profile-icon profile-icon-container"
            onClick={toggleDropdown}
          >
            <FontAwesomeIcon icon={faUser} />
            {isDropdownOpen && (
              <div className="dropdown">
                <ul>
                  <li>
                    <a href="#" onClick={handleMyProfile}>
                      My Profile
                    </a>
                  </li>
                  <li>
                    <a href="#" onClick={handleLogout}>
                      Logout
                    </a>
                  </li>
                </ul>
              </div>
            )}
          </div>
        </header>
        <section className="content">
          <div className="admin-home-container">
            <h2>Search Customer</h2>
            <div className="user-info">
              <p>Email: {email}</p>
              <p>Groups: {groups}</p>
            </div>
            <div className="search-box">
              <input
                type="text"
                placeholder="Search by account number, phone number, or name"
                value={searchInput}
                onChange={handleSearchInputChange}
              />
              <button className="searchbtn" onClick={handleSearch}>
                Search
              </button>
            </div>
            {customerDetails && (
              <div className="customer-card">
                <h3>Customer Details</h3>
                <div className="customer-details">
                  <div className="detail">
                    <p>Name:</p>
                    <p>{customerDetails.name}</p>
                  </div>
                  <div className="detail">
                    <p>Account Number:</p>
                    <p>{customerDetails.accountNumber}</p>
                  </div>
                  <div className="detail">
                    <p>Phone Number:</p>
                    <p>{customerDetails.phoneNumber}</p>
                  </div>
                </div>
              </div>
            )}
          </div>
          {searchPerformed && customerDetails && (
            <div class="vcard">
              <h2>Recharge</h2>
              <h3>Select a Service</h3>
              <div class="radio-group">
                <label>
                  <input type="radio" name="service" value="prepaid" />
                  Prepaid
                </label>
                <label>
                  <input type="radio" name="service" value="postpaid" />
                  Postpaid
                </label>
                <label>
                  <input type="radio" name="service" value="fiber" />
                  Fiber
                </label>
                <label>
                  <input type="radio" name="service" value="dth" />
                  DTH
                </label>
              </div>
              <div class="search-box">
                <input type="text" placeholder="Search for plan" />
              </div>
              <div class="plan-list">
                <div class="plan-card">
                  <div class="plan-details">
                    <div>
                      {" "}
                      <p>Amount: $10</p>
                    </div>
                    <div>
                      <p>Data: 2GB</p>
                    </div>
                    <div>
                      <p>Validity: 30 days</p>
                    </div>
                  </div>
                  <div class="chevron-icon">
                    <FontAwesomeIcon
                      icon={faChevronRight}
                      onClick={handlePayment}
                    />
                  </div>
                </div>
                <div class="plan-card">
                  <div class="plan-details">
                    <div>
                      {" "}
                      <p>Amount: $10</p>
                    </div>
                    <div>
                      <p>Data: 2GB</p>
                    </div>
                    <div>
                      <p>Validity: 30 days</p>
                    </div>
                  </div>
                  <div class="chevron-icon">
                    <FontAwesomeIcon
                      icon={faChevronRight}
                      onClick={handlePayment}
                    />
                  </div>
                </div>
              </div>
            </div>
          )}
        </section>
      </main>
    </div>
  );
}

export default AdminHome;
