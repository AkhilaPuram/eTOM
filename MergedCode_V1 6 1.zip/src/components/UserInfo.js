import "./Customer/orderDetails.css";
import { useEffect } from "react";
const UserInfo = (props) => {
  // console.log(props.userDetails[0].order.customer);
  let Newdata;
  if (props.userDetails.length !== 0) {
    Newdata = props.userDetails[0];
    console.log(Newdata.order.customer);
  }

  // const [data,setData]=useState();
  // // useEffect(()=>setData(props.userDetails[0].order.customer),[props]);

  // useEffect(()=>{setData(Newdata)})
  const {
    title,
    firstName,
    lastName,
    emailID,
    homePhone,
    fax,
    businessPhone,
    customrType,
  } = Newdata.order.customer;
  const {
    priceAmount,
    shippingAddress,
    shippingAmount,
    shippingMethod,
    specialInstructions,
  } = Newdata.order;
  return (
    <div className="Info-container">
      <section className="content">
        <div className="orders-user-info">
          <h3 className="h3heading">UserInfo</h3>
          
          <div className="orders-user-info-items">
            <strong>First Name</strong> <span>{firstName}</span>
          </div>
          <div className="orders-user-info-items">
            <strong>Last Name</strong> <span>{lastName}</span>
          </div>
          <div className="orders-user-info-items">
            <strong>Email</strong> <span>{emailID}</span>
          </div>
          <div className="orders-user-info-items">
            <strong>Home Phone</strong> <span>{homePhone}</span>
          </div>
          
          
        </div>
      </section>
      <section className="content">
        <div className="orders-user-info">
          <h3 className="h3heading">Billing Info</h3>
          <div className="orders-user-info-items">
            <strong>Method</strong>
            <span>{shippingMethod}</span>
          </div>
         
          <div className="orders-user-info-items">
            <strong>Instructions</strong>
            <span>{specialInstructions}</span>
          </div>
          <div className="orders-user-info-items">
            <strong>PriceAmount</strong>
            <span>{priceAmount}</span>
          </div>
          <div className="orders-user-info-items">
            <strong>Shipping Amount</strong>
            <span>{shippingAmount}</span>
          </div>
          
          
        </div>
      </section>
    </div>
  );
};

export default UserInfo;
