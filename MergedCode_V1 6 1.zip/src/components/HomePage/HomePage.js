import React, { useState } from "react";
import Navbar from "../../Navbar/Navbar";
import OrderForm from "./OrderCreation";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUser } from "@fortawesome/free-solid-svg-icons";
import Login from "../Login/Login";
import Keycloak from "keycloak-js";
import { httpClient } from "../../HttpClient";

const HomePage = ({ handleLogin }) => {
  const [showLoginForm, setShowLoginForm] = useState(false);
  const handleLoginClick = () => {
    setShowLoginForm(true);
  };
  const handleGoBack = () => {
    setShowLoginForm(false);
  };
  return (
    <>
      <Navbar
        isLoginPage={showLoginForm}
        setShowLoginForm={setShowLoginForm}
        handleLoginClick={handleLoginClick}
        handleGoBack={handleGoBack}
        handleLogin={handleLogin}
      />
      {/* {showLoginForm ? (
        <Login />
      ) : ( */}
        <OrderForm handleLoginClick={handleLoginClick} />
      {/* )} */}
    </>
  );
};

export default HomePage;
