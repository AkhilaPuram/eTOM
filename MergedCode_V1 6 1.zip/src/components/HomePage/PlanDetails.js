const PlanDetails = {
  Prepaid: [
    {
      productID: "1",
      voice: "FREE",
      validity: "30 days",
      data: "Unlimited",
      price: "599",
      speed: "100 Mbps (100 Mbps Upload & 100 Mbps Download)",
    },
    {
      productID: "2",
      voice: "FREE",
      validity: "30 days",
      data: "Unlimited",
      price: "1499",
      speed: "300 Mbps (300 Mbps Upload and 300 Mbps Download)",
    },
    {
      productID: "3",
      voice: "Free",
      validity: "360 days + 30 days",
      data: "Unlimited",
      price: "4788",
      speed: "30 Mbps (30 Mbps Upload & 30 Mbps Download)",
    },
  ],
  Fiber: [
    {
      productID: "4",
      voice: "NULL",
      validity: "one year",
      data: "Unlimited",
      price: "5988",
      speed: "Up to 40Mbps",
    },
    {
      productID: "5",
      voice: "NULL",
      validity: "One Year",
      data: "Unlimited",
      price: "6499",
      speed: "Up to 45Mbps",
    },
  ],
  Postpaid: [
    {
      productID: "6",
      voice: "FREE",
      validity: "Bill Cycle",
      data: "Unlimited",
      price: "999",
      speed: "150 Mbps (150 Mbps Upload and 150 Mbps Download)",
    },
    {
      productID:"7",
      voice: "FREE",
      validity: "Bill Cycle",
      data: "Unlimited",
      price: "899",
      speed: "100 Mbps (100 Mbps Upload and 100 Mbps Download)",
    },
    {
      productID:"8",
      voice: "FREE",
      validity: "Bill Cycle",
      data: "Unlimited",
      price: "4788",
      speed: "30 Mbps (30 Mbps Upload and 30 Mbps Download)",
    },
  ],
};

export default PlanDetails;
