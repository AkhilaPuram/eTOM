import React, { useState } from "react";
import Login from "../components/Login/Login";
import "./Navbar.css";
import { jwtDecode } from "jwt-decode"; // import dependency
import Keycloak from "keycloak-js";
import { httpClient } from "../HttpClient";
import CustomerHome from "../components/Customer/CustomerHome";
import { useNavigate } from "react-router-dom";
import { useEffect } from "react";
import { useRef } from "react";

function Navbar({
  setShowLoginForm,
  handleGoBack,
  isLoginPage,
  handleLogin,
  handleLogout,
}) {
  const navigate = useNavigate();
  const [kc, setKc] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [loggedIn, setLoggedIn] = useState(false);
  const buttonRef = useRef(null);
  const buttonClickedRef = useRef(false); // Ref to track if the button has been clicked before

  useEffect(() => {
    const searchParams = new URLSearchParams(window.location.search);
    console.log(searchParams);
    console.log("URL --> state-->" + searchParams.has("state"));
    var tempurl = window.location.href;
    var hasState = tempurl.includes("state");
    console.log("TempURL -- state" + hasState);
    if (hasState) {
      console.log("URL -- state" + searchParams.get("state"));
      if (!buttonClickedRef.current && !isLoginPage) {
        buttonRef.current.click();
        console.log("button nclick");
        buttonClickedRef.current = true;
      }
    }
  }, [isLoginPage]);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return (
      <div className="App">
        <h1>Error</h1>
        <p>An error occurred during login. Please try again later.</p>
        <button
          style={{ width: "150px", marginBottom: "20px" }}
          onClick={() => {
            window.location.href = "http://localhost:3000";
          }}
          label=""
        >
          Return to Login
        </button>
      </div>
    );
  }

  if (loggedIn) {
    return (
      <div className="App">
        <div className="grid">
          <div className="col-2">
            <button
              onClick={handleLogout}
              className="m-1 custom-btn-style"
              label=""
              severity="danger"
            >
              Logout
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="navbar">
      <div className="navbar-login">
        {isLoginPage ? (
          <button className="btn-login" onClick={handleGoBack}>
            Go Back
          </button>
        ) : (
          <button className="btn-login" ref={buttonRef} onClick={handleLogin}>
            Login
          </button>
        )}
      </div>
    </div>
  );
}

export default Navbar;
